# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: board-index-hardening.spec.ts >> guest viewing sheet contains focus, dismisses and hands focus across widths
- Location: board-index-hardening.spec.ts:156:7

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('[data-directory-view-sheet]').locator('[data-directory-sort-option=active]')
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" with timeout 5000ms
  - waiting for locator('[data-directory-view-sheet]').locator('[data-directory-sort-option=active]')
    14 × locator resolved to <a data-directory-sort-option="active" href="/?pane=boards&sort=active&peek=3">Active</a>
       - unexpected value "inactive"

```

```yaml
- link "Active":
  - /url: /?pane=boards&sort=active&peek=3
```

# Test source

```ts
  100 |           expectGeometry(metrics);
  101 |           if (index === 0 && [390, 1440].includes(width)) await capture(page, `directory-${width}-${theme}`);
  102 |         }
  103 |         if (index === 0) {
  104 |           for (const width of [320, 861]) {
  105 |             await page.setViewportSize({ width, height: 900 });
  106 |             await page.goto('/?sort=category&peek=3');
  107 |             await appearance(page, theme, true);
  108 |             const metrics = await geometry(page);
  109 |             measurements.push({ name, theme, enlarged: true, ...metrics });
  110 |             writeJson('geometry.json', measurements);
  111 |             expectGeometry(metrics);
  112 |             if (width === 320) await capture(page, `directory-320-${theme}-large-200`);
  113 |           }
  114 |         }
  115 |       }
  116 |     }
  117 |   } finally {
  118 |     fixture("$db->run('UPDATE boards SET name=? WHERE slug=?',[$input['name'],'general']);", { name: original });
  119 |   }
  120 | });
  121 | 
  122 | test('the viewing header does not cover choices in landscape or with enlarged text', async ({ page }) => {
  123 |   for (const { width, height, enlarged } of [
  124 |     { width: 620, height: 320, enlarged: false },
  125 |     { width: 320, height: 844, enlarged: true },
  126 |   ]) {
  127 |     await page.setViewportSize({ width, height });
  128 |     await page.goto('/?sort=category&peek=3');
  129 |     await appearance(page, 'dark', enlarged);
  130 |     const sheet = page.locator('[data-directory-view-sheet]');
  131 |     const summary = sheet.locator('> summary');
  132 |     const panel = sheet.locator('.directory-viewbar-mobile-panel');
  133 |     await summary.click();
  134 |     const headerBox = (await summary.boundingBox())!;
  135 |     const panelBox = (await panel.boundingBox())!;
  136 |     expect(headerBox.y).toBeGreaterThanOrEqual(0);
  137 |     expect(headerBox.y + headerBox.height).toBeLessThanOrEqual(panelBox.y + 1);
  138 |     expect(panelBox.y + panelBox.height).toBeLessThanOrEqual(height + 1);
  139 |     for (const control of await panel.locator('a, button').all()) {
  140 |       await control.focus();
  141 |       const isUncovered = await control.evaluate(element => {
  142 |         const rect = element.getBoundingClientRect();
  143 |         return rect.top >= 0 && rect.bottom <= innerHeight + 1
  144 |           && element.contains(document.elementFromPoint(rect.x + rect.width / 2, rect.y + rect.height / 2));
  145 |       });
  146 |       expect(isUncovered, await control.innerText()).toBeTruthy();
  147 |     }
  148 |     await capture(page, enlarged ? 'sheet-large-200' : 'sheet-landscape');
  149 |     await page.keyboard.press('Escape');
  150 |     await expect(summary).toBeFocused();
  151 |   }
  152 | });
  153 | 
  154 | for (const member of [false, true]) {
  155 |   const audience = member ? 'member' : 'guest';
  156 |   test(`${audience} viewing sheet contains focus, dismisses and hands focus across widths`, async ({ page }) => {
  157 |     if (member) await signIn(page);
  158 |     await page.setViewportSize({ width: 390, height: 844 });
  159 |     await page.goto('/?sort=category&peek=3');
  160 |     const sheet = page.locator('[data-directory-view-sheet]');
  161 |     const shell = page.locator('[data-directory-view-shell]');
  162 |     const summary = sheet.locator('> summary');
  163 |     const last = sheet.getByRole('link', { name: 'Row appearance settings' });
  164 | 
  165 |     await summary.focus();
  166 |     await page.keyboard.press('Enter');
  167 |     await expect(shell).toHaveAttribute('role', 'dialog');
  168 |     await expect(shell).toHaveAttribute('aria-modal', 'true');
  169 |     await expect(sheet.locator('[data-directory-sort-option=category]')).toBeFocused();
  170 |     await expect(page.locator('.forum-bar')).toHaveAttribute('inert', '');
  171 |     await expect(page.locator('.forum-directory__groups')).toHaveAttribute('inert', '');
  172 |     await last.focus();
  173 |     await page.keyboard.press('Tab');
  174 |     await expect(summary).toBeFocused();
  175 |     await page.keyboard.press('Shift+Tab');
  176 |     await expect(last).toBeFocused();
  177 |     expectGeometry(await geometry(page));
  178 | 
  179 |     for (const theme of ['light', 'dark']) {
  180 |       await appearance(page, theme);
  181 |       const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']).analyze();
  182 |       writeJson(`sheet-axe-${audience}-${theme}.json`, results.violations);
  183 |       expect(results.violations).toEqual([]);
  184 |     }
  185 |     await capture(page, `sheet-${audience}-dark`);
  186 |     await page.keyboard.press('Escape');
  187 |     await expect(sheet).not.toHaveAttribute('open', '');
  188 |     await expect(summary).toBeFocused();
  189 |     await expect(page.locator('.forum-bar')).not.toHaveAttribute('inert', '');
  190 |     await expect(page.locator('.forum-directory__groups')).not.toHaveAttribute('inert', '');
  191 | 
  192 |     await summary.click();
  193 |     await page.mouse.click(5, 200);
  194 |     await expect(sheet).not.toHaveAttribute('open', '');
  195 |     await expect(summary).toBeFocused();
  196 | 
  197 |     await summary.focus();
  198 |     await page.keyboard.press('Enter');
  199 |     await page.keyboard.press('Tab');
> 200 |     await expect(sheet.locator('[data-directory-sort-option=active]')).toBeFocused();
      |                                                                        ^ Error: expect(locator).toBeFocused() failed
  201 |     await page.setViewportSize({ width: 1440, height: 900 });
  202 |     await expect(sheet).not.toHaveAttribute('open', '');
  203 |     await expect(shell).not.toHaveAttribute('aria-modal', 'true');
  204 |     await expect(page.locator('.directory-viewbar [data-directory-sort-option=active]')).toBeFocused();
  205 |     await page.setViewportSize({ width: 390, height: 844 });
  206 |     await expect(summary).toBeFocused();
  207 | 
  208 |     await summary.click();
  209 |     await sheet.locator('[data-directory-sort-option=active]').click();
  210 |     await page.waitForURL(url => url.searchParams.get('sort') === 'active');
  211 |     await expect(page.locator('[data-directory-sort]')).toHaveAttribute('data-directory-sort', 'active');
  212 |   });
  213 | 
  214 |   test(`${audience} view remains an inline disclosure and submits with no JavaScript`, async ({ browser, page, baseURL }) => {
  215 |     if (member) await signIn(page);
  216 |     const context = await browser.newContext({
  217 |       baseURL, javaScriptEnabled: false, reducedMotion: 'reduce',
  218 |       viewport: { width: 320, height: 844 },
  219 |       ...(member ? { storageState: await page.context().storageState() } : {}),
  220 |     });
  221 |     try {
  222 |       const native = await context.newPage();
  223 |       await native.goto('/?sort=category&peek=3');
  224 |       const sheet = native.locator('[data-directory-view-sheet]');
  225 |       const summary = sheet.locator('> summary');
  226 |       await summary.click();
  227 |       await expect(sheet).toHaveAttribute('open', '');
  228 |       await expect(sheet.locator('.directory-viewbar-mobile-panel')).toHaveCSS('position', 'static');
  229 |       expectGeometry(await geometry(native));
  230 |       await capture(native, `native-${audience}-view`);
  231 |       await summary.click();
  232 |       await expect(sheet).not.toHaveAttribute('open', '');
  233 |       await summary.click();
  234 |       await sheet.locator('[data-directory-sort-option=active]').click();
  235 |       await native.waitForURL(url => url.searchParams.get('sort') === 'active');
  236 |       await expect(native.locator('[data-directory-sort]')).toHaveAttribute('data-directory-sort', 'active');
  237 |       if (member) {
  238 |         await native.goto('/');
  239 |         await expect(native.locator('[data-directory-sort]')).toHaveAttribute('data-directory-sort', 'active');
  240 |       }
  241 |     } finally { await context.close(); }
  242 |   });
  243 | }
  244 | 
  245 | test('the directory removes unused script requests while creation and sign-in retain their scripts', async ({ page }) => {
  246 |   await page.goto('/');
  247 |   const payload = await page.evaluate(() => performance.getEntriesByType('resource')
  248 |     .filter(e => e.name.endsWith('.js'))
  249 |     .map(e => ({ name: e.name.split('/').pop(), decodedBytes: (e as PerformanceResourceTiming).decodedBodySize })));
  250 |   writeJson('script-payload.json', payload);
  251 |   expect(payload.some(e => e.name?.startsWith('composer-') || e.name?.startsWith('passkeys-'))).toBeFalsy();
  252 |   await page.goto('/login');
  253 |   await expect(page.locator('script[src*="/passkeys-"]')).toHaveCount(1);
  254 |   await signIn(page);
  255 |   await page.goto('/');
  256 |   await expect(page.locator('script[src*="/composer-"], script[src*="/passkeys-"]')).toHaveCount(0);
  257 |   await page.locator('[data-create-menu] > summary').click();
  258 |   await page.getByRole('link', { name: 'New topic', exact: true }).click();
  259 |   await page.waitForURL(url => url.pathname === '/compose');
  260 |   await expect(page.locator('script[src*="/composer-"]')).toHaveCount(1);
  261 |   await expect(page.locator('form.composer')).toBeVisible();
  262 | });
  263 | 
```